package com.cg.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.capstore.dto.Customer;
import com.cg.capstore.dto.Merchant;
import com.cg.capstore.dto.Product;
import com.cg.capstore.service.ICapstoreService;



@Controller
public class AdminController {

	@Autowired
	ICapstoreService CapstoreService;
	
	@RequestMapping(value="getCustomerlist", method=RequestMethod.GET)
	public String showCustomerList(Model model){
		List<Customer> list=CapstoreService.getAllCustomers();
		model.addAttribute("list", list);
		return "CustomersHome";
	}
	
	@RequestMapping(value="getMerchantlist", method=RequestMethod.GET)
	public String showMerchantList(Model model){
		List<Merchant> list=CapstoreService.getAllMerchants();
		model.addAttribute("list", list);
		return "MerchantsHome";
	}
	
	@RequestMapping(value="getProductlist", method=RequestMethod.GET)
	public String showProductList(Model model){
		List<Product> list=CapstoreService.getAllProducts();
		model.addAttribute("list", list);
		return "ProductsHome";
	}
}
