package com.cg.capstore.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.capstore.dto.Customer;
import com.cg.capstore.dto.Merchant;
import com.cg.capstore.dto.Product;



@Repository
@Transactional
public class CapStoreDaoImpl implements ICapstoreDao {


	@PersistenceContext
	EntityManager manager;
	@Override
	public List<Customer> getAllCustomers() {
		TypedQuery<Customer> queryOne=manager.createQuery("FROM Customer",Customer.class);
		List<Customer> myList=queryOne.getResultList();
				return myList;
	}
	@Override
	public List<Merchant> getAllMerchants() {
		TypedQuery<Merchant> queryOne=manager.createQuery("FROM Merchant",Merchant.class);
		List<Merchant> myList=queryOne.getResultList();
				return myList;
	}
	@Override
	public List<Product> getAllProducts() {
		
			TypedQuery<Product> queryOne=manager.createQuery("FROM Product",Product.class);
			List<Product> myList=queryOne.getResultList();
					return myList;
	}

}
