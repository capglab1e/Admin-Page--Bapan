package com.cg.capstore.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Merchant_Details")
public class Merchant {
	@Id
	@Column(name="merchant_id")
	private String userId;
	
	@Column(name="merchant_name")
	private String name;
	
	@Column(name="merchant_company_name")
	private String companyName;
	
	@Column(name="merchant_company_address")
	private String companyAddress;
	
	@Column(name="merchant_mobileno")
	private String phoneNo;
	
	@Column(name="merchant_rating")
	private float rating;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyAddress() {
		return companyAddress;
	}
	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public float getRating() {
		return rating;
	}
	public void setRating(float rating) {
		this.rating = rating;
	}
	public Merchant(String userId, String name, String companyName,
			String companyAddress, String phoneNo, float rating) {
		super();
		this.userId = userId;
		this.name = name;
		this.companyName = companyName;
		this.companyAddress = companyAddress;
		this.phoneNo = phoneNo;
		this.rating = rating;
	}
	public Merchant() {
		super();
		
	}
	
	
	

}
