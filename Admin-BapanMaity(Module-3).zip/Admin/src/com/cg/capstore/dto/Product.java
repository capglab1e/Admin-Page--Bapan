package com.cg.capstore.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Product")
public class Product {
	
	@Id
	@Column(name="prod_id")
	private String productId;
	
	@Column(name="prod_name")
	private String prodName;
	
	@Column(name="price")
	private double price;
	
	@Column(name="category_Id")
	private String categoryId;
	
	@Column(name="subcategory_Id")
	private String subCategoryId;
	
	@Column(name="rating")
	private float rating;
	
	@Column(name="QTY_Supplied")
	private int quantitySupplied;
	
	@Column(name="QTY_Available")
	private int quantityAvailable;
	
	@Column(name="merchant_id")
	private String merchantId;
	
	@Column(name="Description")
	private String prodDesc;

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	public String getSubCategoryId() {
		return subCategoryId;
	}

	public void setSubCategoryId(String subCategoryId) {
		this.subCategoryId = subCategoryId;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public int getQuantitySupplied() {
		return quantitySupplied;
	}

	public void setQuantitySupplied(int quantitySupplied) {
		this.quantitySupplied = quantitySupplied;
	}

	public int getQuantityAvailable() {
		return quantityAvailable;
	}

	public void setQuantityAvailable(int quantityAvailable) {
		this.quantityAvailable = quantityAvailable;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getProdDesc() {
		return prodDesc;
	}

	public void setProdDesc(String prodDesc) {
		this.prodDesc = prodDesc;
	}

	public Product(String productId, String prodName, double price, String categoryId,
			String subCategoryId, float rating, int quantitySupplied,
			int quantityAvailable, String merchantId, String prodDesc) {
		super();
		this.productId = productId;
		this.prodName = prodName;
		this.price = price;
		this.categoryId = categoryId;
		this.subCategoryId = subCategoryId;
		this.rating = rating;
		this.quantitySupplied = quantitySupplied;
		this.quantityAvailable = quantityAvailable;
		this.merchantId = merchantId;
		this.prodDesc = prodDesc;
	}

	public Product() {
		super();
		
	}
	
	

}
