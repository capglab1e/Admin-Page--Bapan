package com.cg.capstore.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.ICapstoreDao;
import com.cg.capstore.dto.Customer;
import com.cg.capstore.dto.Merchant;
import com.cg.capstore.dto.Product;


@Service
@Transactional
public class CapStoreServiceImpl implements ICapstoreService {

	@Autowired
	ICapstoreDao CapstoreDao;
	@Override
	public List<Customer> getAllCustomers() {
		return CapstoreDao.getAllCustomers();
	}
	@Override
	public List<Merchant> getAllMerchants() {
		
		return CapstoreDao.getAllMerchants();
	}
	@Override
	public List<Product> getAllProducts() {
		
		return CapstoreDao.getAllProducts();
	}

}
