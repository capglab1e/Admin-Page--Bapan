package com.cg.capstore.service;

import java.util.List;
import com.cg.capstore.dto.Customer;
import com.cg.capstore.dto.Merchant;
import com.cg.capstore.dto.Product;



public interface ICapstoreService {
	public List <Customer> getAllCustomers();
	public List <Merchant> getAllMerchants();
	public List <Product> getAllProducts();
}
